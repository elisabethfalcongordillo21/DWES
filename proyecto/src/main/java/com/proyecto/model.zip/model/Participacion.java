package com.proyecto.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
public class Participacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fase;
    private Integer puesto;
    private Integer puntos;

    @ManyToOne
    @JoinColumn(name = "agrupacion_id")
    private Agrupacion agrupacion;

    @ManyToOne
    @JoinColumn(name = "concurso_id")
    private Concurso concurso;

    @OneToMany(mappedBy = "participacion")
    private List<Cancion> canciones = new ArrayList<>();
}
