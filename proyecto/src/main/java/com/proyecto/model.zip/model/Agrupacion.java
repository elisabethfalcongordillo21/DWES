package com.proyecto.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
public class Agrupacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    @Column(length = 2000)
    private String descripcion;

    private String localidad;
    private Integer anioFundacion;
    private String fotoUrl;

    @ManyToOne
    @JoinColumn(name = "modalidad_id")
    private Modalidad modalidad;

    @OneToOne(mappedBy = "agrupacion", cascade = CascadeType.ALL)
    private Tipo tipo;

    @OneToMany(mappedBy = "agrupacion")
    private List<Participacion> participaciones = new ArrayList<>();

   
    @ManyToMany(mappedBy = "agrupaciones")
    private List<Autor> autores = new ArrayList<>();
}
